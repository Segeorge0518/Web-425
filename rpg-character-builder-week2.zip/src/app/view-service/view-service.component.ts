import { Component } from '@angular/core';

@Component({
  selector: 'app-view-service',
  standalone: true,
  imports: [],
  template: `
    <p>
      view-service works!
    </p>
  `,
  styles: ``
})
export class ViewServiceComponent {

}
