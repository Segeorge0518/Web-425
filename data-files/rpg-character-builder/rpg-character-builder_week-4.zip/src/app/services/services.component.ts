import { Component } from '@angular/core';

@Component({
  selector: 'app-services',
  standalone: true,
  imports: [],
  template: `
    <p>
      services works!
    </p>
  `,
  styles: ``
})
export class ServicesComponent {

}
